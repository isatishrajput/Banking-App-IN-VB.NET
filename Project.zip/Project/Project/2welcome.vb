﻿Public Class welcome

    Private Sub form1_load(sender As Object, e As EventArgs) Handles MyBase.Load
        Login.TopLevel = False
        Panel1.Controls.Add(Login)
        Login.BringToFront()
        Login.Show()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Register.TopLevel = False
        Panel1.Controls.Add(Register)
        Register.BringToFront()
        Register.Show()
    End Sub
End Class
