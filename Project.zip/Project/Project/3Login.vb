﻿Public Class Login

    Private Sub log_showpass_CheckedChanged(sender As Object, e As EventArgs) Handles log_showpass.CheckedChanged
        If log_showpass.Checked = True Then
            txt_log_pass.UseSystemPasswordChar = True
        Else
            txt_log_pass.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click

    End Sub
End Class