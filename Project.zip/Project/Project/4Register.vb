﻿Public Class Register
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Me.Dispose()
    End Sub

    Private Sub show_pass_CheckedChanged(sender As Object, e As EventArgs) Handles show_pass.CheckedChanged
        If show_pass.Checked = True Then
            txt_pass.UseSystemPasswordChar = True
        Else
            txt_pass.UseSystemPasswordChar = False
        End If
    End Sub
End Class