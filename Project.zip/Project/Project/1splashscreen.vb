﻿Imports System.Windows

Public Class splashscreen
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Panel2.Width += 3
        If Panel2.Width >= 900 Then
            welcome.Show()
            Me.Close()
        End If
    End Sub
End Class