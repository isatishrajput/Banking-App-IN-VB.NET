﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.LOANPLANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOANTYPEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INTERESTRATEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CUSTOMERDETAILToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EMICALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOANAPPLICATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 28)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LOANPLANToolStripMenuItem, Me.CUSTOMERDETAILToolStripMenuItem, Me.EMICALToolStripMenuItem, Me.LOANAPPLICATIONToolStripMenuItem, Me.ToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'LOANPLANToolStripMenuItem
        '
        Me.LOANPLANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LOANTYPEToolStripMenuItem, Me.INTERESTRATEToolStripMenuItem})
        Me.LOANPLANToolStripMenuItem.Name = "LOANPLANToolStripMenuItem"
        Me.LOANPLANToolStripMenuItem.Size = New System.Drawing.Size(101, 24)
        Me.LOANPLANToolStripMenuItem.Text = "LOAN PLAN"
        '
        'LOANTYPEToolStripMenuItem
        '
        Me.LOANTYPEToolStripMenuItem.Name = "LOANTYPEToolStripMenuItem"
        Me.LOANTYPEToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.LOANTYPEToolStripMenuItem.Text = "LOAN TYPE"
        '
        'INTERESTRATEToolStripMenuItem
        '
        Me.INTERESTRATEToolStripMenuItem.Name = "INTERESTRATEToolStripMenuItem"
        Me.INTERESTRATEToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.INTERESTRATEToolStripMenuItem.Text = "INTEREST RATE"
        '
        'CUSTOMERDETAILToolStripMenuItem
        '
        Me.CUSTOMERDETAILToolStripMenuItem.Name = "CUSTOMERDETAILToolStripMenuItem"
        Me.CUSTOMERDETAILToolStripMenuItem.Size = New System.Drawing.Size(153, 24)
        Me.CUSTOMERDETAILToolStripMenuItem.Text = " CUSTOMER DETAIL"
        '
        'EMICALToolStripMenuItem
        '
        Me.EMICALToolStripMenuItem.Name = "EMICALToolStripMenuItem"
        Me.EMICALToolStripMenuItem.Size = New System.Drawing.Size(78, 24)
        Me.EMICALToolStripMenuItem.Text = "EMI CAL"
        '
        'LOANAPPLICATIONToolStripMenuItem
        '
        Me.LOANAPPLICATIONToolStripMenuItem.Name = "LOANAPPLICATIONToolStripMenuItem"
        Me.LOANAPPLICATIONToolStripMenuItem.Size = New System.Drawing.Size(154, 24)
        Me.LOANAPPLICATIONToolStripMenuItem.Text = "LOAN APPLICATION"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(152, 24)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents LOANPLANToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LOANTYPEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents INTERESTRATEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CUSTOMERDETAILToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EMICALToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LOANAPPLICATIONToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
End Class
